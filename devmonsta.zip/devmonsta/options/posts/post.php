<?php

use Devmonsta\Libs\Posts;

class Post extends Posts
{

    public function register_controls()
    {

        $this->add_box([
            'id' => 'post_box_1',
            'post_type' => 'post',
            'title' => 'Metabox for post',
        ]);

        $this->add_box([
            'id' => 'post_box_2',
            'post_type' => 'post',
            'title' => 'Another metabox for post',
        ]);

        $this->add_control([
            'box_id' => 'post_box_1',
            'type' => 'password',
            
        ]);

        $this->add_control([
            'box_id' => 'post_box_1',
            'type' => 'text',
            'name' => 'fname',
            'label' => 'First name',
        ]);

        $this->add_control([
            'box_id' => 'post_box_1',
            'type' => 'email',
            'name' => 'my_email',
            'label' => 'Email',
        ]);

        $this->add_control([
            'box_id' => 'post_box_2',
            'type' => 'text',
            'name' => 'txt_mobile',
            'label' => 'mobile',
        ]);

        $this->add_control([
            'box_id' => 'page_box_2',
            'type' => 'text',
            'name' => 'txt_pass',
            'label' => 'Passowrd',
        ]);

    }

}
